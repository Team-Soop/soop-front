import logo from './logo.svg';
import './App.css';
import AuthRoute from './Routes/AuthRoute';
import FeedPage from './pages/FeedPage/FeedPage';

function App() {
  return (
    <>
      {/* // layout
      // container
      // sidebar */}
      <AuthRoute/>
    </>
  );
}

export default App;
