import React from 'react'

const ReportCompleted = () => {
  return (
    <div>
      
    </div>
  )
}

export default ReportCompleted
