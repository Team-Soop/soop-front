import { css } from "@emotion/react";

export const container = css`
    z-index: -99;
    position: absolute;
    width: 100%;
    height: 100%;
`;