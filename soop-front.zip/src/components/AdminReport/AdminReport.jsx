import React, { useState } from 'react';

import AdminReportSearch from './AdminReportSearch/AdminReportSearch';

function AdminReport(props) {
  


  return (
    <div>
      

      <AdminReportSearch/>
    </div>
  );
}

export default AdminReport;