/** @jsxImportSource @emotion/react */
import * as s from "./style";

function RootSideMenuLeft(props) {
  return (
    <div css={s.layout}>
      
    </div>
  );
}

export default RootSideMenuLeft;