import { css } from "@emotion/react";

export const calendar = css`
    
    

    .fc-day-sun a {
        color: red;
    }

    .fc-day-sat a {
        color: blue;
    }
`