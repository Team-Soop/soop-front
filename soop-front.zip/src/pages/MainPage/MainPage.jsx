import React from 'react';

function MainPage(props) {
  return (
    <div>
      
    </div>
  );
}

export default MainPage;