import React, { useState } from 'react';
import SaveStudyGroup from '../../components/SaveStudyGroup/SaveStduyGroup'

function StudyGroupPage(props) {
	
  return (
    <>
		<header>
			<button>글쓰기</button>
		</header>
		<body>

		</body>
		<SaveStudyGroup/>
	</>
  );
}

export default StudyGroupPage;