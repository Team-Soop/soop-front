import React from 'react';

function LunchRecommendationDetailePage(props) {
  return (
    <div>
      
    </div>
  );
}

export default LunchRecommendationDetailePage;