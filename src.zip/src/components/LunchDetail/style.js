import { css } from "@emotion/react";

export const imgLayOut = css`
  border: 1px solid black;
  width: 120px;
  height: 120px;
`