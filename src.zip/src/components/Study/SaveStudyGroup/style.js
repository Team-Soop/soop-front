import { css } from "@emotion/react";

export const checkBoxList = css`
    display: flex;
`