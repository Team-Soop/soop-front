import { atom } from "recoil";

export const lunchDetailState = atom({
  key: "lunchDetailState",
  default: []
})