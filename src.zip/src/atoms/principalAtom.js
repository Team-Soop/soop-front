import { atom } from "recoil";

export const principalState = atom({
    key: "principalState",
    default: null
});