import { atom } from "recoil";

export const lunchMapTitlState = atom({
  key: "lunchMapTitlState",
  default: ""
});

export const lunchMapXState = atom({
  key: "lunchMapXState",
  default: ""
});

export const lunchMapYState = atom({
  key: "lunchMapYState",
  default: ""
});

export const lunchMapPlaceUrlState = atom({
  key: "lunchMapPlaceUrlState",
  default: ""
})