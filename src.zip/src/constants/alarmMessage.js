export const alarmMessage = {
  reportComplete: {
    text: "<p>최근 유저님이 접수하신 신고내역에 따라 해당글과 유저가 제재를받았습니다.<p></p>건전한 글쓰기 문화에 동참해주셔서 감사합니다.</p>"
  }
}