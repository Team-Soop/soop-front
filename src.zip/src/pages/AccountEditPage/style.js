import { css } from "@emotion/react";

export const accountEditPage = css`
  box-sizing: border-box;
  padding: 30px 0;
  width: 700px;

`

export const accountEditButtons = css`
  width: 100%;
  button {
    
  }
`