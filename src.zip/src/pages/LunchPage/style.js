import { css } from "@emotion/react";

export const componentsLayout = css`
  background-color: #dbdbdb;
`

export const detailLayout = css`
  background-color: #a6e2a4;
`