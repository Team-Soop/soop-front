import { css } from "@emotion/react";

export const mypageFeedRootLayout = css`
  position: relative;
  padding: 20px 0;
`;