import ReportSearch from '../../components/AdminReport/ReportSearch/ReportSearch';
import ReportCompleted from '../../components/AdminReport/ReportCompleted/ReportCompleted';

function AdminReport() {



  return (
    <div>
      <ReportSearch />
      <ReportCompleted />
    </div>
  );
}

export default AdminReport;